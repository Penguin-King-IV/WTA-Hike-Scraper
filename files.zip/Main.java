package com.wta.scraper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.wta.model.Hike;

import java.io.File;
import java.util.List;
import java.util.Map;

/**
 * Entry point — scrapes WTA and demonstrates Java Stream filtering.
 *
 * Usage:
 *   java -jar wta-scraper.jar [maxHikes]
 *
 * Default: scrapes 60 hikes (2 listing pages). Pass a larger number to get more.
 */
public class Main {

    public static void main(String[] args) throws Exception {

        // ── 1. Scrape ─────────────────────────────────────────────────────────
        int maxHikes = args.length > 0 ? Integer.parseInt(args[0]) : 60;

        System.out.println("=== WTA Hike Scraper ===");
        System.out.println("Scraping up to " + maxHikes + " hikes...\n");

        WtaScraper scraper = new WtaScraper();
        List<Hike> allHikes = scraper.scrape(maxHikes);

        System.out.println("\nTotal hikes scraped: " + allHikes.size());

        // ── 2. Save raw data to JSON ──────────────────────────────────────────
        ObjectMapper mapper = new ObjectMapper()
                .enable(SerializationFeature.INDENT_OUTPUT);
        File jsonFile = new File("hikes.json");
        mapper.writeValue(jsonFile, allHikes);
        System.out.println("Saved to: " + jsonFile.getAbsolutePath());

        // ── 3. Build repository ───────────────────────────────────────────────
        HikeRepository repo = new HikeRepository(allHikes);

        // ── 4. Example filters (edit these to suit your needs) ────────────────

        System.out.println("\n--- Dog-friendly hikes under 8 miles ---");
        repo.filterByTag("Dogs allowed on leash")
            .filterByMaxLength(8)
            .sortByLength()
            .toList()
            .forEach(h -> System.out.printf("  %-40s %.1f mi  gain=%.0f ft%n",
                    h.getName(), h.getLengthMiles(), h.getElevationGainFeet()));

        System.out.println("\n--- Hikes in the Olympics area with wildflowers ---");
        repo.filterByArea("Olympics")
            .filterByTag("Wildflowers/Meadows")
            .sortByElevationGain()
            .toList()
            .forEach(h -> System.out.printf("  %-40s gain=%.0f ft  hi=%.0f ft%n",
                    h.getName(), h.getElevationGainFeet(), h.getHighestPointFeet()));

        System.out.println("\n--- Hardest hike (most elevation gain) ---");
        repo.hardestHike().ifPresent(h ->
                System.out.println("  " + h));

        System.out.println("\n--- Average hike length ---");
        System.out.printf("  %.1f miles%n", repo.averageLength());

        System.out.println("\n--- All unique tags found ---");
        repo.allTags().forEach(t -> System.out.println("  " + t));

        System.out.println("\n--- Hikes grouped by area (count) ---");
        Map<String, List<Hike>> byArea = repo.groupByArea();
        byArea.entrySet().stream()
              .sorted((a, b) -> b.getValue().size() - a.getValue().size())
              .forEach(e -> System.out.printf("  %-35s %d hikes%n",
                      e.getKey(), e.getValue().size()));
    }
}
