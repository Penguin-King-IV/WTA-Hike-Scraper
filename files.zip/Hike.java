package com.wta.model;

import java.util.List;

/**
 * Represents a single hike scraped from WTA (Washington Trails Association).
 */
public class Hike {

    private String name;
    private String areaLocation;
    private double lengthMiles;       // round trip miles
    private double highestPointFeet;  // highest elevation in feet
    private double elevationGainFeet; // total gain in feet
    private List<String> tags;        // e.g. ["Kid-friendly", "Dog-friendly", "Wildflowers"]
    private String url;               // source URL on wta.org

    public Hike() {}

    public Hike(String name, String areaLocation, double lengthMiles,
                double highestPointFeet, double elevationGainFeet,
                List<String> tags, String url) {
        this.name = name;
        this.areaLocation = areaLocation;
        this.lengthMiles = lengthMiles;
        this.highestPointFeet = highestPointFeet;
        this.elevationGainFeet = elevationGainFeet;
        this.tags = tags;
        this.url = url;
    }

    // ── Getters ──────────────────────────────────────────────────────────────

    public String getName()              { return name; }
    public String getAreaLocation()      { return areaLocation; }
    public double getLengthMiles()       { return lengthMiles; }
    public double getHighestPointFeet()  { return highestPointFeet; }
    public double getElevationGainFeet() { return elevationGainFeet; }
    public List<String> getTags()        { return tags; }
    public String getUrl()               { return url; }

    // ── Setters ──────────────────────────────────────────────────────────────

    public void setName(String name)                        { this.name = name; }
    public void setAreaLocation(String areaLocation)        { this.areaLocation = areaLocation; }
    public void setLengthMiles(double lengthMiles)          { this.lengthMiles = lengthMiles; }
    public void setHighestPointFeet(double highestPointFeet){ this.highestPointFeet = highestPointFeet; }
    public void setElevationGainFeet(double elevationGainFeet){ this.elevationGainFeet = elevationGainFeet; }
    public void setTags(List<String> tags)                  { this.tags = tags; }
    public void setUrl(String url)                          { this.url = url; }

    // ── Convenience helpers for stream filtering ──────────────────────────────

    /** Returns true if the hike has the given tag (case-insensitive). */
    public boolean hasTag(String tag) {
        return tags != null && tags.stream()
                .anyMatch(t -> t.equalsIgnoreCase(tag));
    }

    /** Returns true if the hike area contains the given keyword (case-insensitive). */
    public boolean isInArea(String keyword) {
        return areaLocation != null &&
               areaLocation.toLowerCase().contains(keyword.toLowerCase());
    }

    @Override
    public String toString() {
        return String.format(
            "Hike{name='%s', area='%s', length=%.1f mi, highPt=%.0f ft, gain=%.0f ft, tags=%s}",
            name, areaLocation, lengthMiles, highestPointFeet, elevationGainFeet, tags
        );
    }
}
