package com.wta.scraper;

import com.wta.model.Hike;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Scrapes hike data from Washington Trails Association (wta.org).
 *
 * WTA listing URL pattern:
 *   https://www.wta.org/go-hiking/hikes?b_start:int=0   (first page, 30 results)
 *   https://www.wta.org/go-hiking/hikes?b_start:int=30  (second page, etc.)
 *
 * Each hike detail page lives at:
 *   https://www.wta.org/go-hiking/hikes/<hike-slug>
 */
public class WtaScraper {

    private static final String BASE_URL        = "https://www.wta.org";
    private static final String LISTING_URL     = BASE_URL + "/go-hiking/hikes";
    private static final int    PAGE_SIZE       = 30;
    private static final int    REQUEST_DELAY_MS = 1_000; // be polite

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Scrape up to {@code maxHikes} hikes from WTA.
     * Pass Integer.MAX_VALUE to scrape everything.
     */
    public List<Hike> scrape(int maxHikes) throws IOException, InterruptedException {
        List<Hike> hikes = new ArrayList<>();
        int offset = 0;

        while (hikes.size() < maxHikes) {
            String pageUrl = LISTING_URL + "?b_start:int=" + offset;
            System.out.println("Fetching listing page: " + pageUrl);

            List<String> hikeUrls = fetchHikeUrlsFromListing(pageUrl);
            if (hikeUrls.isEmpty()) {
                System.out.println("No more hikes found. Stopping.");
                break;
            }

            for (String hikeUrl : hikeUrls) {
                if (hikes.size() >= maxHikes) break;
                try {
                    Hike hike = scrapeHikeDetail(hikeUrl);
                    if (hike != null) {
                        hikes.add(hike);
                        System.out.printf("  [%d] Scraped: %s%n", hikes.size(), hike.getName());
                    }
                    Thread.sleep(REQUEST_DELAY_MS);
                } catch (Exception e) {
                    System.err.println("  Failed to scrape " + hikeUrl + " — " + e.getMessage());
                }
            }

            offset += PAGE_SIZE;
        }

        return hikes;
    }

    // ── Listing page ─────────────────────────────────────────────────────────

    /**
     * Returns all hike detail URLs found on one WTA listing page.
     */
    List<String> fetchHikeUrlsFromListing(String listingUrl) throws IOException {
        Document doc = fetchDocument(listingUrl);
        List<String> urls = new ArrayList<>();

        // Each hike card is inside: <div class="search-result-item"> ... <a class="listitem-title">
        Elements links = doc.select("div.search-result-item a.listitem-title");
        for (Element link : links) {
            String href = link.absUrl("href");
            if (!href.isEmpty()) {
                urls.add(href);
            }
        }

        // Fallback selector used in older WTA layouts
        if (urls.isEmpty()) {
            Elements fallback = doc.select("h3.title a[href*=/go-hiking/hikes/]");
            for (Element link : fallback) {
                String href = link.absUrl("href");
                if (!href.isEmpty()) urls.add(href);
            }
        }

        return urls;
    }

    // ── Detail page ───────────────────────────────────────────────────────────

    /**
     * Scrapes a single WTA hike detail page into a {@link Hike} object.
     *
     * WTA detail page key selectors (as of 2024):
     *   Name            : h1.documentFirstHeading
     *   Area/Region     : div#hike-region span.hike-stat-text  (or breadcrumb)
     *   Length          : div#distance span.hike-stat-text
     *   Highest point   : div#high-point span.hike-stat-text
     *   Elevation gain  : div#gain span.hike-stat-text
     *   Tags/Features   : div.hike-features span.feature-name
     */
    Hike scrapeHikeDetail(String url) throws IOException {
        Document doc = fetchDocument(url);
        Hike hike = new Hike();
        hike.setUrl(url);

        // ── Name ──────────────────────────────────────────────────────────────
        Element nameEl = doc.selectFirst("h1.documentFirstHeading");
        if (nameEl == null) nameEl = doc.selectFirst("h1");
        hike.setName(nameEl != null ? nameEl.text().trim() : "Unknown");

        // ── Area / Location ───────────────────────────────────────────────────
        // WTA shows breadcrumb like: Go Hiking > Regions > Olympics & Coast > Hike Name
        Elements breadcrumbs = doc.select("div#breadcrumbs a, nav.breadcrumb a");
        if (breadcrumbs.size() >= 3) {
            // Third breadcrumb is typically the region
            hike.setAreaLocation(breadcrumbs.get(breadcrumbs.size() - 2).text().trim());
        } else {
            Element regionEl = doc.selectFirst("div#hike-region span.hike-stat-text");
            if (regionEl == null) regionEl = doc.selectFirst("span.hike-region");
            hike.setAreaLocation(regionEl != null ? regionEl.text().trim() : "Unknown");
        }

        // ── Stats block ───────────────────────────────────────────────────────
        // WTA wraps stats in elements like:
        //   <div id="distance"><span class="hike-stat-label">…</span>
        //                       <span class="hike-stat-text">5.4 miles, roundtrip</span></div>
        hike.setLengthMiles(parseStatMiles(doc, "#distance", "miles"));
        hike.setHighestPointFeet(parseStatFeet(doc, "#high-point"));
        hike.setElevationGainFeet(parseStatFeet(doc, "#gain"));

        // ── Tags / Features ───────────────────────────────────────────────────
        List<String> tags = new ArrayList<>();
        Elements featureEls = doc.select("div.hike-features span.feature-name, " +
                                         "ul.hike-tags li, " +
                                         "div.trip-features .feature span");
        for (Element el : featureEls) {
            String tag = el.text().trim();
            if (!tag.isEmpty()) tags.add(tag);
        }
        hike.setTags(tags);

        return hike;
    }

    // ── Parsing helpers ───────────────────────────────────────────────────────

    private double parseStatMiles(Document doc, String cssId, String unit) {
        Element el = doc.selectFirst(cssId + " span.hike-stat-text");
        if (el == null) el = doc.selectFirst(cssId);
        if (el == null) return 0.0;
        return extractFirstDouble(el.text());
    }

    private double parseStatFeet(Document doc, String cssId) {
        Element el = doc.selectFirst(cssId + " span.hike-stat-text");
        if (el == null) el = doc.selectFirst(cssId);
        if (el == null) return 0.0;
        // Remove commas from numbers like "4,321"
        String text = el.text().replace(",", "");
        return extractFirstDouble(text);
    }

    private static final Pattern DOUBLE_PATTERN = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)");

    private double extractFirstDouble(String text) {
        if (text == null) return 0.0;
        Matcher m = DOUBLE_PATTERN.matcher(text);
        return m.find() ? Double.parseDouble(m.group(1)) : 0.0;
    }

    // ── HTTP helper ───────────────────────────────────────────────────────────

    private Document fetchDocument(String url) throws IOException {
        return Jsoup.connect(url)
                .userAgent("Mozilla/5.0 (compatible; WtaHikeScraper/1.0)")
                .header("Accept-Language", "en-US,en;q=0.9")
                .timeout(15_000)
                .get();
    }
}
