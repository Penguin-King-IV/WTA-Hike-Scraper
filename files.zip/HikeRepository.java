package com.wta.scraper;

import com.wta.model.Hike;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * In-memory store for scraped {@link Hike} objects.
 *
 * All "filter" methods return a new {@code HikeRepository} so calls can be chained:
 *
 * <pre>{@code
 * List<Hike> results = repo
 *     .filterByArea("Olympics")
 *     .filterByMaxLength(10)
 *     .filterByTag("Dog-friendly")
 *     .sortByElevationGain()
 *     .toList();
 * }</pre>
 */
public class HikeRepository {

    private final List<Hike> hikes;

    public HikeRepository(List<Hike> hikes) {
        this.hikes = Collections.unmodifiableList(new ArrayList<>(hikes));
    }

    // ── Factory / access ─────────────────────────────────────────────────────

    /** Returns the underlying stream — use for custom operations. */
    public Stream<Hike> stream() {
        return hikes.stream();
    }

    /** Materialises the current view into a plain list. */
    public List<Hike> toList() {
        return new ArrayList<>(hikes);
    }

    /** Total number of hikes in this repository. */
    public int size() { return hikes.size(); }

    // ── Filters (each returns a new HikeRepository) ──────────────────────────

    /**
     * Keep hikes whose area/location contains {@code keyword} (case-insensitive).
     * e.g. filterByArea("Olympics"), filterByArea("Cascades")
     */
    public HikeRepository filterByArea(String keyword) {
        return wrap(hikes.stream().filter(h -> h.isInArea(keyword)));
    }

    /**
     * Keep hikes shorter than or equal to {@code maxMiles} (round-trip).
     */
    public HikeRepository filterByMaxLength(double maxMiles) {
        return wrap(hikes.stream().filter(h -> h.getLengthMiles() <= maxMiles));
    }

    /**
     * Keep hikes longer than or equal to {@code minMiles} (round-trip).
     */
    public HikeRepository filterByMinLength(double minMiles) {
        return wrap(hikes.stream().filter(h -> h.getLengthMiles() >= minMiles));
    }

    /**
     * Keep hikes within a length range (inclusive, round-trip miles).
     */
    public HikeRepository filterByLengthRange(double minMiles, double maxMiles) {
        return wrap(hikes.stream()
                .filter(h -> h.getLengthMiles() >= minMiles && h.getLengthMiles() <= maxMiles));
    }

    /**
     * Keep hikes with elevation gain ≤ {@code maxFeet}.
     */
    public HikeRepository filterByMaxGain(double maxFeet) {
        return wrap(hikes.stream().filter(h -> h.getElevationGainFeet() <= maxFeet));
    }

    /**
     * Keep hikes with elevation gain ≥ {@code minFeet}.
     */
    public HikeRepository filterByMinGain(double minFeet) {
        return wrap(hikes.stream().filter(h -> h.getElevationGainFeet() >= minFeet));
    }

    /**
     * Keep hikes whose highest point is at or above {@code minFeet}.
     */
    public HikeRepository filterByMinElevation(double minFeet) {
        return wrap(hikes.stream().filter(h -> h.getHighestPointFeet() >= minFeet));
    }

    /**
     * Keep hikes that have the given tag (case-insensitive).
     * e.g. filterByTag("Dog-friendly"), filterByTag("Wildflowers")
     */
    public HikeRepository filterByTag(String tag) {
        return wrap(hikes.stream().filter(h -> h.hasTag(tag)));
    }

    /**
     * Keep hikes that have ALL of the given tags.
     */
    public HikeRepository filterByAllTags(String... tags) {
        return wrap(hikes.stream()
                .filter(h -> {
                    for (String tag : tags) {
                        if (!h.hasTag(tag)) return false;
                    }
                    return true;
                }));
    }

    /**
     * Keep hikes that have ANY of the given tags.
     */
    public HikeRepository filterByAnyTag(String... tags) {
        return wrap(hikes.stream()
                .filter(h -> {
                    for (String tag : tags) {
                        if (h.hasTag(tag)) return true;
                    }
                    return false;
                }));
    }

    // ── Sorting ───────────────────────────────────────────────────────────────

    public HikeRepository sortByName() {
        return wrap(hikes.stream().sorted(Comparator.comparing(Hike::getName)));
    }

    public HikeRepository sortByLength() {
        return wrap(hikes.stream().sorted(Comparator.comparingDouble(Hike::getLengthMiles)));
    }

    public HikeRepository sortByElevationGain() {
        return wrap(hikes.stream().sorted(Comparator.comparingDouble(Hike::getElevationGainFeet)));
    }

    public HikeRepository sortByHighestPoint() {
        return wrap(hikes.stream().sorted(Comparator.comparingDouble(Hike::getHighestPointFeet).reversed()));
    }

    // ── Aggregations ─────────────────────────────────────────────────────────

    /** Hike with the longest distance. */
    public Optional<Hike> longestHike() {
        return hikes.stream().max(Comparator.comparingDouble(Hike::getLengthMiles));
    }

    /** Hike with the most elevation gain. */
    public Optional<Hike> hardestHike() {
        return hikes.stream().max(Comparator.comparingDouble(Hike::getElevationGainFeet));
    }

    /** Average length across all hikes in this repository. */
    public double averageLength() {
        return hikes.stream().mapToDouble(Hike::getLengthMiles).average().orElse(0.0);
    }

    /** Group hikes by area/location string. */
    public Map<String, List<Hike>> groupByArea() {
        return hikes.stream().collect(Collectors.groupingBy(Hike::getAreaLocation));
    }

    /** Collect every unique tag across all hikes. */
    public List<String> allTags() {
        return hikes.stream()
                .flatMap(h -> h.getTags() != null ? h.getTags().stream() : Stream.empty())
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }

    // ── Internal ──────────────────────────────────────────────────────────────

    private HikeRepository wrap(Stream<Hike> stream) {
        return new HikeRepository(stream.collect(Collectors.toList()));
    }
}
